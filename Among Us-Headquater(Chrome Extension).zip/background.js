const BASE_URL = "https://thejantako.github.io/Among-Us-Headquater/player.html";
const REMOTE_URL = "https://thejantako.github.io/Among-Us-Headquater/remote.html";

let peer = null;
let activeConn = null;
let myPeerId = null;

// --- 1. ANTI-SLEEP HACK FÜR FIREFOX ---
// Täuscht alle 15 Sekunden eine API-Aktion vor, damit Firefox
// das Hintergrund-Skript niemals in den Ruhezustand versetzt.
setInterval(() => {
  chrome.storage.local.get('keep_alive_hack');
  chrome.runtime.getPlatformInfo(() => {});
}, 15000);
// --------------------------------------

function initPeer() {
  if (peer && !peer.destroyed && !peer.disconnected) return;

  chrome.storage.local.get(['saved_peer_id'], (res) => {
    const customId = res.saved_peer_id || undefined;

    if (peer) {
      try { peer.destroy(); } catch(e) {}
    }

    // --- 2. PEERJS SERVER TIMEOUT VERHINDERN ---
    // pingInterval: 10000 sendet alle 10 Sek ein Signal an den Server,
    // damit dieser uns nicht nach 1 Minute Inaktivität kickt.
    peer = new Peer(customId, {
      pingInterval: 10000
    });

    peer.on('open', (id) => {
      myPeerId = id;
      chrome.storage.local.set({ saved_peer_id: id });
    });

    peer.on('disconnected', () => {
      if (peer && !peer.destroyed) {
        peer.reconnect();
      }
    });

    peer.on('error', (err) => {
      console.error("PeerJS Error:", err);
      if (err.type === 'unavailable-id') {
        chrome.storage.local.remove('saved_peer_id', () => {
          setTimeout(initPeer, 1000);
        });
      } else {
        setTimeout(initPeer, 3000);
      }
    });

    peer.on('connection', (conn) => {
      activeConn = conn;

      conn.on('open', () => {
        sendSyncToPhone();
      });

      conn.on('data', (data) => {
        if (data.type === 'UPDATE_STREAMERS') {
          const newStreamers = data.streamers;
          chrome.storage.local.set({ app_streamers: newStreamers }, () => {
            triggerTabsUpdate(newStreamers);
          });
        } else if (data.type === 'RELOAD_TABS') {
          reloadPlayerTabs();
        } else if (data.type === 'PING') {
          // Beantwortet den Herzschlag vom Handy
          if (activeConn && activeConn.open) {
            activeConn.send({ type: 'PONG' });
          }
        }
      });

      conn.on('close', () => {
        activeConn = null;
      });

      conn.on('error', () => {
        activeConn = null;
      });
    });
  });
}

chrome.runtime.onStartup.addListener(() => { initPeer(); });
chrome.runtime.onInstalled.addListener(() => { initPeer(); });

function sendSyncToPhone() {
  if (activeConn && activeConn.open) {
    chrome.storage.local.get(['app_streamers'], (res) => {
      activeConn.send({ type: 'SYNC', streamers: res.app_streamers || [] });
    });
  }
}

function triggerTabsUpdate(streamers) {
  chrome.storage.local.get(['app_mode'], (res) => {
    const mode = res.app_mode || '2';
    const actives = streamers.filter(s => s.active);
    const s1Names = mode === '1' ? actives.map(s => s.name) : actives.filter(s => s.star || s.sword).map(s => s.name);
    const s2Names = mode === '1' ? [] : actives.filter(s => !s.star && !s.sword).map(s => s.name);

    const targetUrl1 = `${BASE_URL}#screen=1&channels=${s1Names.join(',')}`;
    const targetUrl2 = `${BASE_URL}#screen=2&channels=${s2Names.join(',')}`;

    chrome.tabs.query({ url: "*://*.github.io/*player.html*" }, (tabs) => {
      let tab1 = tabs.find(t => t.url.includes('screen=1'));
      let tab2 = tabs.find(t => t.url.includes('screen=2'));

      if (tab1) chrome.tabs.update(tab1.id, { url: targetUrl1 });
      if (mode === '2' && tab2) chrome.tabs.update(tab2.id, { url: targetUrl2 });
    });
  });
}

function reloadPlayerTabs() {
  chrome.tabs.query({ url: "*://*.github.io/*player.html*" }, (tabs) => {
    tabs.forEach(t => chrome.tabs.reload(t.id));
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'GET_PEER_STATUS') {
    if (!myPeerId && (!peer || peer.destroyed)) {
      initPeer();
    }
    sendResponse({ peerId: myPeerId, connected: activeConn && activeConn.open });
  } else if (request.action === 'SYNC_DATA') {
    sendSyncToPhone();
  } else if (request.action === 'OPEN_REMOTE_WINDOW') {
    if (myPeerId) {
      chrome.windows.create({
        url: `${REMOTE_URL}?id=${myPeerId}`,
        type: 'popup',
        width: 400,
        height: 700
      });
    }
  }
  return true;
});

initPeer();