const BASE_URL = "https://thejantako.github.io/Among-Us-Headquater/player.html";

let peer = null;
let activeConn = null;
let myPeerId = null;

function initPeer() {
  if (peer && !peer.destroyed) return;

  peer = new Peer();

  peer.on('open', (id) => {
    myPeerId = id;
  });

  peer.on('disconnected', () => {
    if (peer && !peer.destroyed) {
      peer.reconnect();
    }
  });

  peer.on('error', (err) => {
    console.error("PeerJS Error in Offscreen:", err);
    setTimeout(initPeer, 3000);
  });

  peer.on('connection', (conn) => {
    activeConn = conn;

    conn.on('open', () => {
      sendSyncToPhone();
    });

    conn.on('data', (data) => {
      if (data.type === 'UPDATE_STREAMERS') {
        chrome.storage.local.set({ app_streamers: data.streamers }, () => {
          triggerTabsUpdate(data.streamers);
        });
      } else if (data.type === 'RELOAD_TABS') {
        reloadPlayerTabs();
      }
    });

    conn.on('close', () => {
      activeConn = null;
    });
  });
}

function sendSyncToPhone() {
  if (activeConn && activeConn.open) {
    chrome.storage.local.get(['app_streamers'], (res) => {
      activeConn.send({ type: 'SYNC', streamers: res.app_streamers || [] });
    });
  }
}

function triggerTabsUpdate(streamers) {
  chrome.storage.local.get(['app_mode'], (res) => {
    const mode = res.app_mode || '2';
    const actives = streamers.filter(s => s.active);
    const s1Names = mode === '1' ? actives.map(s => s.name) : actives.filter(s => s.star || s.sword).map(s => s.name);
    const s2Names = mode === '1' ? [] : actives.filter(s => !s.star && !s.sword).map(s => s.name);

    const targetUrl1 = `${BASE_URL}#screen=1&channels=${s1Names.join(',')}`;
    const targetUrl2 = `${BASE_URL}#screen=2&channels=${s2Names.join(',')}`;

    chrome.tabs.query({ url: "*://*.github.io/*player.html*" }, (tabs) => {
      let tab1 = tabs.find(t => t.url.includes('screen=1'));
      let tab2 = tabs.find(t => t.url.includes('screen=2'));

      if (tab1) chrome.tabs.update(tab1.id, { url: targetUrl1 });
      if (mode === '2' && tab2) chrome.tabs.update(tab2.id, { url: targetUrl2 });
    });
  });
}

function reloadPlayerTabs() {
  chrome.tabs.query({ url: "*://*.github.io/*player.html*" }, (tabs) => {
    tabs.forEach(t => chrome.tabs.reload(t.id));
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'GET_PEER_STATUS') {
    sendResponse({ peerId: myPeerId, connected: activeConn && activeConn.open });
  } else if (request.action === 'SYNC_DATA') {
    sendSyncToPhone();
  }
  return true;
});

initPeer();