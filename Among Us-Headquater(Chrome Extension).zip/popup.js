const BASE_URL = "https://thejantako.github.io/Among-Us-Headquater/player.html";
const REMOTE_URL = "https://thejantako.github.io/Among-Us-Headquater/remote.html";

document.addEventListener('DOMContentLoaded', () => {
  let mode = '2';
  let streamers = [];

  const mode1Btn = document.getElementById('mode-1-btn');
  const mode2Btn = document.getElementById('mode-2-btn');
  const openWin1Btn = document.getElementById('open-win1-btn');
  const openWin2Btn = document.getElementById('open-win2-btn');
  const togglePoolBtn = document.getElementById('toggle-pool-btn');
  const poolView = document.getElementById('pool-view');
  const poolList = document.getElementById('pool-list');
  const newPoolInput = document.getElementById('new-pool-input');
  const addPoolBtn = document.getElementById('add-pool-btn');
  const closePoolBtn = document.getElementById('close-pool-btn');
  const activeList = document.getElementById('active-list');
  const applyBtn = document.getElementById('apply-btn');
  const syncBtn = document.getElementById('sync-btn');
  
  const toggleQrBtn = document.getElementById('toggle-qr-btn');
  const qrBox = document.getElementById('qrcode-box');
  const qrContainer = document.getElementById('qrcode');
  const qrStatus = document.getElementById('qr-status');

  function loadData() {
    browser.storage.local.get(['app_mode', 'app_streamers']).then((res) => {
      mode = res.app_mode || '2';
      streamers = res.app_streamers || [];
      updateModeUI();
      render();
    });
  }

  function saveData() {
    browser.storage.local.set({ app_mode: mode, app_streamers: streamers }).then(() => {
      render();
      browser.runtime.sendMessage({ action: 'SYNC_DATA' });
      triggerTabsUpdate();
    });
  }

  function updateModeUI() {
    if (mode === '1') {
      mode1Btn.classList.add('active');
      mode2Btn.classList.remove('active');
      openWin2Btn.style.display = 'none';
    } else {
      mode2Btn.classList.add('active');
      mode1Btn.classList.remove('active');
      openWin2Btn.style.display = 'block';
    }
  }

  mode1Btn.onclick = () => { mode = '1'; updateModeUI(); saveData(); };
  mode2Btn.onclick = () => { mode = '2'; updateModeUI(); saveData(); };

  openWin1Btn.onclick = () => browser.tabs.create({ url: `${BASE_URL}#screen=1` });
  openWin2Btn.onclick = () => browser.tabs.create({ url: `${BASE_URL}#screen=2` });

  togglePoolBtn.onclick = () => poolView.style.display = poolView.style.display === 'block' ? 'none' : 'block';
  closePoolBtn.onclick = () => poolView.style.display = 'none';

  addPoolBtn.onclick = addPoolStreamer;
  newPoolInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') addPoolStreamer(); });

  function addPoolStreamer() {
    const name = newPoolInput.value.trim().toLowerCase();
    if (name && !streamers.some(s => s.name === name)) {
      streamers.push({ name, active: true, star: false, sword: false });
      newPoolInput.value = '';
      saveData();
    }
  }

  function render() {
    poolList.innerHTML = '';
    streamers.forEach((s, idx) => {
      const row = document.createElement('div');
      row.className = 'pool-row';
      row.innerHTML = `
        <label style="cursor:pointer;"><input type="checkbox" ${s.active ? 'checked' : ''}> <strong>${s.name}</strong></label>
        <span class="delete-btn" title="Löschen">✕</span>
      `;
      row.querySelector('input').onchange = (e) => { streamers[idx].active = e.target.checked; saveData(); };
      row.querySelector('.delete-btn').onclick = () => { streamers.splice(idx, 1); saveData(); };
      poolList.appendChild(row);
    });

    activeList.innerHTML = '';
    const actives = streamers.filter(s => s.active);
    actives.forEach((s) => {
      const idx = streamers.findIndex(item => item.name === s.name);
      const row = document.createElement('div');
      row.className = 'streamer-row';
      row.innerHTML = `
        <span class="icon-btn star-btn ${s.star ? 'active' : ''}">⭐</span>
        <span class="streamer-name">${s.name}</span>
        <span class="icon-btn sword-btn ${s.sword ? 'active' : ''}">⚔️</span>
      `;
      row.querySelector('.star-btn').onclick = () => { streamers[idx].star = !streamers[idx].star; saveData(); };
      row.querySelector('.sword-btn').onclick = () => { streamers[idx].sword = !streamers[idx].sword; saveData(); };
      activeList.appendChild(row);
    });
  }

  toggleQrBtn.onclick = () => {
    if (qrBox.style.display === 'block') {
      qrBox.style.display = 'none';
      return;
    }

    qrBox.style.display = 'block';
    qrContainer.innerHTML = '<div style="color:#666; font-size:12px; line-height:140px;">Lade QR...</div>';
    qrStatus.textContent = "Verbindung wird hergestellt...";

    function fetchPeerStatus(retries = 15) {
      browser.runtime.sendMessage({ action: 'GET_PEER_STATUS' }).then((response) => {
        if (response && response.peerId) {
          qrContainer.innerHTML = '';
          const fullUrl = `${REMOTE_URL}?id=${response.peerId}`;
          new QRCode(qrContainer, { text: fullUrl, width: 140, height: 140 });

          if (response.connected) {
            qrStatus.textContent = "🟢 Handy Verbunden!";
          } else {
            qrStatus.textContent = "Warte auf Verbindung...";
          }
        } else if (retries > 0) {
          setTimeout(() => fetchPeerStatus(retries - 1), 300);
        } else {
          qrStatus.textContent = "❌ Fehler beim Laden der ID";
        }
      }).catch(() => {
        if (retries > 0) setTimeout(() => fetchPeerStatus(retries - 1), 300);
      });
    }

    fetchPeerStatus();
  };

  qrContainer.onclick = () => {
    browser.runtime.sendMessage({ action: 'OPEN_REMOTE_WINDOW' });
  };

  function triggerTabsUpdate() {
    const actives = streamers.filter(s => s.active);
    const s1Names = mode === '1' ? actives.map(s => s.name) : actives.filter(s => s.star || s.sword).map(s => s.name);
    const s2Names = mode === '1' ? [] : actives.filter(s => !s.star && !s.sword).map(s => s.name);

    const targetUrl1 = `${BASE_URL}#screen=1&channels=${s1Names.join(',')}`;
    const targetUrl2 = `${BASE_URL}#screen=2&channels=${s2Names.join(',')}`;

    browser.tabs.query({ url: "*://*.github.io/*player.html*" }).then((tabs) => {
      let tab1 = tabs.find(t => t.url.includes('screen=1'));
      let tab2 = tabs.find(t => t.url.includes('screen=2'));

      if (tab1) browser.tabs.update(tab1.id, { url: targetUrl1 });
      if (mode === '2' && tab2) browser.tabs.update(tab2.id, { url: targetUrl2 });
    });
  }

  applyBtn.onclick = () => {
    triggerTabsUpdate();
    applyBtn.textContent = '✓ Aktualisiert!';
    setTimeout(() => { applyBtn.textContent = 'Tabs Aktualisieren'; }, 1000);
  };

  syncBtn.onclick = () => {
    browser.tabs.query({ url: "*://*.github.io/*player.html*" }).then((tabs) => {
      tabs.forEach(t => browser.tabs.reload(t.id));
    });
  };

  loadData();
});